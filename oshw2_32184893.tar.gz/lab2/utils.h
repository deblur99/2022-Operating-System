// 학번: 32184893
// 학과: 모바일시스템공학과
// 이름: 한현민

// ransom note 출력하는 파일

#pragma once

#include <stdio.h>
#include <string.h>

void printAsciiArtOnEncryption();

void printAsciiArtOnDecryption();