// 학번: 32184893
// 학과: 모바일시스템공학과
// 이름: 한현민

#pragma once

#include "defines.h"

void printInputCondition();

bool isValidInput(int argc, char *argv[]);