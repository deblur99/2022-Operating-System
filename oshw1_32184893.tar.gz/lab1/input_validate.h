#pragma once

#include "defines.h"

void printInputCondition();

bool isValidInput(int argc, char *argv[]);