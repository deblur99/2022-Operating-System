// 학번: 32184893
// 학과: 모바일시스템공학과
// 이름: 한현민

#pragma once

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

typedef struct _INPUT_DATA {
  int x;
  int y;
  int interval;
} INPUT_DATA;